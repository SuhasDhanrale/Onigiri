const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./PokiAdapter-D5noX-wn.js","./index-CFy-NPpN.js","./index-e5zRgAxD.css","./CrazyGamesAdapter-BhED2J9l.js","./AdMobAdapter-E9VNDYqu.js","./GameDistributionAdapter-DdWI7acC.js"])))=>i.map(i=>d[i]);
import{_ as p,b as u}from"./index-CFy-NPpN.js";const d={platform:"crazygames",CG_SDK_ONLY:!0,levelRules:{noAdsUntilLevel:5,showAdEveryNLevels:3,totalLevels:30},timing:{interstitialCooldown:6e4,globalCooldown:3e4,initialDelay:3e4,dummyInterstitialDuration:3e3,dummyRewardedDuration:5e3},frequencyCaps:{maxInterstitialsPerSession:10,maxRewardedPerSession:50,interstitialEveryNGameOvers:2},shop:{upgradesWithRewardedOption:{speed:!0,damage:!0,shield:!0},maxContinuesPerAttempt:1},placements:{admob:{interstitial:"ca-app-pub-XXXXXXX/interstitial",rewarded:"ca-app-pub-XXXXXXX/rewarded",banner:"ca-app-pub-XXXXXXX/banner"},poki:{interstitial:"poki_interstitial",rewarded:"poki_rewarded"},crazygames:{interstitial:"crazygames_interstitial",rewarded:"crazygames_rewarded"},gamedistribution:{interstitial:"gamedistribution_interstitial",rewarded:"gamedistribution_rewarded"},playgama:{interstitial:"playgama_interstitial",rewarded:"playgama_rewarded",banner:"playgama_banner"},development:{interstitial:"dummy_interstitial",rewarded:"dummy_rewarded",banner:"dummy_banner"}}};function y(l){const e=d.platform;return(d.placements[e]||d.placements.development)[l]||`unknown_${l}`}function m(){return!1}function I(l){return d.shop.upgradesWithRewardedOption[l]===!0}function A(l){const{noAdsUntilLevel:e,showAdEveryNLevels:t}=d.levelRules;if(l<e)return!1;const a=l-e;return a>=0&&a%t===0}function x(){const l=[];for(let e=1;e<=d.levelRules.totalLevels;e++)A(e)&&l.push(e);return l}console.log("[AdConfig] Interstitial levels:",x());class v{constructor(e){this.name=e,this.initialized=!1}async init(){throw new Error("init() must be implemented by subclass")}async showInterstitial(e){throw new Error("showInterstitial() must be implemented by subclass")}async showRewardedAd(e){throw new Error("showRewardedAd() must be implemented by subclass")}async showBanner(e){throw new Error("showBanner() must be implemented by subclass")}async hideBanner(){throw new Error("hideBanner() must be implemented by subclass")}isAdAvailable(e){throw new Error("isAdAvailable() must be implemented by subclass")}async preloadAd(e){throw new Error("preloadAd() must be implemented by subclass")}log(e,t={}){console.log(`[${this.name}] ${e}`,t)}}class g extends v{constructor(){super("DummyAdapter"),this.overlayElement=null,this.adReady={interstitial:!0,rewarded:!0,banner:!0}}async init(){return this.log("Initialized - Ready for testing"),this.initialized=!0,this._createOverlayStyles(),!0}_createOverlayStyles(){if(document.getElementById("dummy-ad-styles"))return;const e=document.createElement("style");e.id="dummy-ad-styles",e.textContent=`
            .dummy-ad-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.9);
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                z-index: 99999;
                font-family: 'Segoe UI', Arial, sans-serif;
                color: white;
            }

            .dummy-ad-overlay .ad-type {
                font-size: 14px;
                text-transform: uppercase;
                letter-spacing: 3px;
                color: #888;
                margin-bottom: 10px;
            }

            .dummy-ad-overlay .ad-title {
                font-size: 32px;
                font-weight: bold;
                margin-bottom: 30px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .dummy-ad-overlay .countdown {
                font-size: 72px;
                font-weight: bold;
                margin-bottom: 30px;
                text-shadow: 0 0 20px rgba(102, 126, 234, 0.5);
            }

            .dummy-ad-overlay .ad-message {
                font-size: 16px;
                color: #aaa;
                margin-bottom: 30px;
            }

            .dummy-ad-overlay .skip-button {
                padding: 12px 40px;
                font-size: 16px;
                background: transparent;
                border: 2px solid #667eea;
                color: #667eea;
                border-radius: 30px;
                cursor: pointer;
                transition: all 0.3s ease;
                text-transform: uppercase;
                letter-spacing: 2px;
            }

            .dummy-ad-overlay .skip-button:hover {
                background: #667eea;
                color: white;
            }

            .dummy-ad-overlay .skip-button:disabled {
                opacity: 0.3;
                cursor: not-allowed;
            }

            .dummy-ad-overlay .complete-button {
                padding: 12px 40px;
                font-size: 16px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border: none;
                color: white;
                border-radius: 30px;
                cursor: pointer;
                transition: all 0.3s ease;
                text-transform: uppercase;
                letter-spacing: 2px;
                margin-top: 15px;
            }

            .dummy-ad-overlay .complete-button:hover {
                transform: scale(1.05);
                box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
            }

            .dummy-ad-overlay .progress-bar {
                width: 300px;
                height: 4px;
                background: #333;
                border-radius: 2px;
                overflow: hidden;
                margin-bottom: 20px;
            }

            .dummy-ad-overlay .progress-bar .progress {
                height: 100%;
                background: linear-gradient(90deg, #667eea, #764ba2);
                transition: width 0.1s linear;
            }

            .dummy-ad-banner {
                position: fixed;
                left: 0;
                width: 100%;
                height: 60px;
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 99998;
                border: 1px solid #333;
                font-family: 'Segoe UI', Arial, sans-serif;
            }

            .dummy-ad-banner.top { top: 0; }
            .dummy-ad-banner.bottom { bottom: 0; }

            .dummy-ad-banner .banner-text {
                color: #667eea;
                font-size: 14px;
                letter-spacing: 2px;
                text-transform: uppercase;
            }
        `,document.head.appendChild(e)}_showOverlay(e,t,a=!1){return new Promise(n=>{this._removeOverlay();const r=document.createElement("div");r.className="dummy-ad-overlay",r.id="dummy-ad-overlay";const o=Math.ceil(t/1e3);let s=o;r.innerHTML=`
                <div class="ad-type">${e==="rewarded"?"🎁 Rewarded Video":"📺 Interstitial"}</div>
                <div class="ad-title">AD PLAYING</div>
                <div class="countdown">${s}s</div>
                <div class="progress-bar"><div class="progress" style="width: 0%"></div></div>
                <div class="ad-message">This is a simulated ${e} ad for testing</div>
                ${a?`
                    <button class="skip-button" disabled>Skip in ${s}s</button>
                    <button class="complete-button" style="display: none;">✓ Complete & Get Reward</button>
                `:""}
            `,document.body.appendChild(r),this.overlayElement=r;const i=r.querySelector(".countdown"),_=r.querySelector(".progress"),c=r.querySelector(".skip-button"),h=r.querySelector(".complete-button"),w=2,f=setInterval(()=>{s--;const S=(o-s)/o*100;i.textContent=`${Math.max(0,s)}s`,_.style.width=`${S}%`,a&&s<=o-w?(c.disabled=!1,c.textContent="Skip Ad"):a&&(c.textContent=`Skip in ${s-(o-w)}s`),s<=0&&(clearInterval(f),a?(c.style.display="none",h.style.display="block"):(this._removeOverlay(),n({success:!0})))},1e3);c&&c.addEventListener("click",()=>{c.disabled||(clearInterval(f),this._removeOverlay(),this.log("Ad skipped by user"),n({success:!0,rewarded:!1}))}),h&&h.addEventListener("click",()=>{this._removeOverlay(),this.log("Rewarded ad completed"),n({success:!0,rewarded:!0})})})}_removeOverlay(){this.overlayElement&&(this.overlayElement.remove(),this.overlayElement=null);const e=document.getElementById("dummy-ad-overlay");e&&e.remove()}async showInterstitial(e){this.log("showInterstitial",{placement:e});const t=d.timing.dummyInterstitialDuration;return await this._showOverlay("interstitial",t,!1)}async showRewardedAd(e){this.log("showRewardedAd",{placement:e});const t=d.timing.dummyRewardedDuration;return await this._showOverlay("rewarded",t,!0)}async showBanner(e="bottom"){this.log("showBanner",{position:e}),this.hideBanner();const t=document.createElement("div");return t.className=`dummy-ad-banner ${e}`,t.id="dummy-ad-banner",t.innerHTML='<span class="banner-text">📢 Banner Advertisement</span>',document.body.appendChild(t),{success:!0}}async hideBanner(){const e=document.getElementById("dummy-ad-banner");e&&(e.remove(),this.log("Banner hidden"))}isAdAvailable(e){return this.adReady[e]??!0}async preloadAd(e){return this.log("preloadAd",{adType:e}),await new Promise(t=>setTimeout(t,100)),this.adReady[e]=!0,!0}}class b extends v{constructor(){super("FallbackAdapter")}async init(){return this.log("Initialized - Ads are disabled"),this.initialized=!0,!0}async showInterstitial(e){return this.log("showInterstitial (no-op)",{placement:e}),{success:!0}}async showRewardedAd(e){return this.log("showRewardedAd (no-op)",{placement:e}),{success:!0,rewarded:!0}}async showBanner(e){return this.log("showBanner (no-op)",{position:e}),{success:!0}}async hideBanner(){}isAdAvailable(e){return!0}async preloadAd(e){return!0}}class M{constructor(){this.initialized=!1,this.adapter=null,this.initPromise=null,this._pendingCalls=[],this.sessionStats={interstitialsShown:0,rewardedShown:0,gameOvers:0,levelCompletes:0,continuesUsed:0},this.attemptStats={continuesUsed:0},this.lastAdTime=0,this.lastInterstitialTime=0,this.sessionStartTime=Date.now(),this.bannerVisible=!1,this.startupInterstitialShown=!1,this.startupInterstitialGateInstalled=!1,this.startupInterstitialInProgress=!1}_isCrazyGamesSdkOnlyMode(){return d.CG_SDK_ONLY===!0}async init(){if(this.initialized&&this.adapter)return!0;if(this.initPromise)return this.initPromise;this.initPromise=(async()=>{const e=this._isCrazyGamesSdkOnlyMode();return!m()&&!e?(console.log("[AdManager] Ads disabled via config"),this.adapter=new b,await this.adapter.init(),this.initialized=!0,!0):(e&&console.log("[AdManager] CrazyGames SDK-only mode enabled (ads disabled, SDK active)"),this.adapter=await this._createAdapter(),await this.adapter.init()||(console.log("[AdManager] Adapter failed to init, falling back to FallbackAdapter"),this.adapter=new b,await this.adapter.init()),this._setupEventListeners(),this.initialized=!0,this._flushPendingCalls(),console.log(`[AdManager] Initialized with ${this.adapter.name}`),!0)})();try{return await this.initPromise}finally{this.initPromise=null}}async _ensureInitialized(){return this.initialized&&this.adapter?!0:(await this.init(),this.adapter?!0:(console.error("[AdManager] No adapter available after init"),!1))}_callAdapterMethod(e,...t){if(!this.adapter){this._pendingCalls.push({methodName:e,args:t});return}if(typeof this.adapter[e]=="function")try{return this.adapter[e](...t)}catch(a){console.warn(`[AdManager] Adapter method failed: ${e}`,a)}}_flushPendingCalls(){const e=this._pendingCalls;this._pendingCalls=[];for(const{methodName:t,args:a}of e)this._callAdapterMethod(t,...a)}async _createAdapter(){switch(d.platform){case"poki":try{const{PokiAdapter:t}=await p(async()=>{const{PokiAdapter:a}=await import("./PokiAdapter-D5noX-wn.js");return{PokiAdapter:a}},__vite__mapDeps([0,1,2]),import.meta.url);return new t}catch{console.log("[AdManager] PokiAdapter not available")}break;case"crazygames":try{const{CrazyGamesAdapter:t}=await p(async()=>{const{CrazyGamesAdapter:a}=await import("./CrazyGamesAdapter-BhED2J9l.js");return{CrazyGamesAdapter:a}},__vite__mapDeps([3,1,2]),import.meta.url);return new t}catch{console.log("[AdManager] CrazyGamesAdapter not available")}break;case"mobile":try{const{AdMobAdapter:t}=await p(async()=>{const{AdMobAdapter:a}=await import("./AdMobAdapter-E9VNDYqu.js");return{AdMobAdapter:a}},__vite__mapDeps([4,1,2]),import.meta.url);return new t}catch{console.log("[AdManager] AdMobAdapter not available")}break;case"gamedistribution":try{const{GameDistributionAdapter:t}=await p(async()=>{const{GameDistributionAdapter:a}=await import("./GameDistributionAdapter-DdWI7acC.js");return{GameDistributionAdapter:a}},__vite__mapDeps([5,1,2]),import.meta.url);return new t}catch{console.log("[AdManager] GameDistributionAdapter not available")}break;case"playgama":try{const{PlaygamaAdapter:t}=await p(async()=>{const{PlaygamaAdapter:a}=await import("../ads/adapters/PlaygamaAdapter.js");return{PlaygamaAdapter:a}},[],import.meta.url);return new t}catch{console.log("[AdManager] PlaygamaAdapter not available")}break;case"web":case"development":default:return new g}return new g}_setupEventListeners(){u.on("level:fail",()=>{this.sessionStats.gameOvers++}),u.on("level:complete",()=>{this.sessionStats.levelCompletes++}),u.on("level:start",()=>{this.attemptStats.continuesUsed=0})}async showInterstitial(e="default",t={}){const a=(t==null?void 0:t.force)===!0;if(this._isCrazyGamesSdkOnlyMode())return console.log(`[AdManager] SDK-only mode: interstitial blocked (${e})`),!1;if(!await this._ensureInitialized())return!1;if(!a&&!this._canShowAd("interstitial"))return console.log("[AdManager] Cannot show interstitial - cooldown or cap reached"),!1;const n=y("interstitial");console.log(`[AdManager] Showing interstitial: ${e}`),u.emit("ad:started",{type:"interstitial",placement:e});try{const r=await this.adapter.showInterstitial(n);return r.success?(this.sessionStats.interstitialsShown++,this.lastAdTime=Date.now(),this.lastInterstitialTime=Date.now(),u.emit("ad:completed",{type:"interstitial",placement:e})):u.emit("ad:failed",{type:"interstitial",placement:e,error:r.error}),r.success}catch(r){return console.error("[AdManager] Interstitial error:",r),u.emit("ad:failed",{type:"interstitial",placement:e,error:r.message}),!1}}async showStartupInterstitialOnce(){return this.startupInterstitialShown?!1:(this.startupInterstitialShown=!0,await this.showInterstitial("startup_gate",{force:!0}))}installStartupInterstitialGate(){if(this.startupInterstitialGateInstalled||!m())return!1;this.startupInterstitialGateInstalled=!0;const e=["pointerdown","mousedown","touchstart","click"],t=s=>{this.startupInterstitialInProgress&&(s.cancelable&&s.preventDefault(),typeof s.stopImmediatePropagation=="function"&&s.stopImmediatePropagation(),s.stopPropagation())},a=()=>{e.forEach(s=>{window.addEventListener(s,t,{capture:!0,passive:!1})})},n=()=>{e.forEach(s=>{window.removeEventListener(s,t,!0)}),this.startupInterstitialInProgress=!1},r=()=>{window.removeEventListener("pointerdown",o,!0),window.removeEventListener("mousedown",o,!0),window.removeEventListener("touchstart",o,!0)},o=async s=>{if(this.startupInterstitialInProgress){t(s);return}this.startupInterstitialInProgress=!0,t(s),a();try{await this.showStartupInterstitialOnce()}finally{n(),r()}};return window.addEventListener("pointerdown",o,{capture:!0,passive:!1}),window.addEventListener("mousedown",o,{capture:!0,passive:!1}),window.addEventListener("touchstart",o,{capture:!0,passive:!1}),!0}async showRewardedAd(e="default",t=null){var n,r,o,s;if(this._isCrazyGamesSdkOnlyMode())return console.log(`[AdManager] SDK-only mode: rewarded blocked (${e})`),t&&t(!1),!1;if(!await this._ensureInitialized())return t&&t(!1),!1;if(!this._canShowAd("rewarded"))return console.log("[AdManager] Cannot show rewarded - cooldown reached"),t&&t(!1),!1;const a=y("rewarded");console.log(`[AdManager] Showing rewarded ad: ${e}`),u.emit("ad:started",{type:"rewarded",placement:e});try{const i=await this.adapter.showRewardedAd(a);return console.info("[RewardDebug][AdManager] Adapter rewarded result",{placement:e,placementId:a,adapter:(n=this.adapter)==null?void 0:n.name,result:i}),i.success?(this.sessionStats.rewardedShown++,this.lastAdTime=Date.now(),i.rewarded?u.emit("ad:rewarded",{type:"rewarded",placement:e}):u.emit("ad:skipped",{type:"rewarded",placement:e}),t&&t(i.rewarded,{opened:!0,placement:e,placementId:a,adapter:(r=this.adapter)==null?void 0:r.name,result:i})):(u.emit("ad:failed",{type:"rewarded",placement:e,error:i.error}),t&&t(!1,{opened:!1,placement:e,placementId:a,adapter:(o=this.adapter)==null?void 0:o.name,result:i})),i.success}catch(i){return console.error("[AdManager] Rewarded ad error:",i),u.emit("ad:failed",{type:"rewarded",placement:e,error:i.message}),t&&t(!1,{opened:!1,placement:e,placementId:a,adapter:(s=this.adapter)==null?void 0:s.name,error:(i==null?void 0:i.message)||String(i)}),!1}}async showInterstitialAfterLevel(e){return A(e)?this._canShowAd("interstitial")?await this.showInterstitial(`level_${e}_complete`):(console.log(`[AdManager] Ad eligible after level ${e} but blocked by cooldown/cap`),!1):(console.log(`[AdManager] No ad after level ${e} (per level rules)`),!1)}async showInterstitialOnGameOver(){const e=d.frequencyCaps.interstitialEveryNGameOvers;return(this.sessionStats.gameOvers+1)%e!==0?(console.log(`[AdManager] No ad on game over (${this.sessionStats.gameOvers+1} of ${e})`),!1):await this.showInterstitial("game_over")}canUseRewardedForUpgrade(e){return I(e)}async offerRewardedForUpgrade(e,t,a=null,n=null){if(!this.canUseRewardedForUpgrade(e)){console.log(`[AdManager] ${e} doesn't support rewarded ads`),n&&n();return}await this.showRewardedAd(`upgrade_${e}_${t}`,r=>{r?a&&a():n&&n()})}async offerRewardedForContinue(e=null,t=null){return this.attemptStats.continuesUsed>=d.shop.maxContinuesPerAttempt?(console.log("[AdManager] Max continues reached for this attempt"),!1):(await this.showRewardedAd("continue_game",a=>{a?(this.attemptStats.continuesUsed++,this.sessionStats.continuesUsed++,e&&e()):t&&t()}),!0)}canOfferContinue(){return!(this.attemptStats.continuesUsed>=d.shop.maxContinuesPerAttempt)}async showBanner(e="bottom"){if(!await this._ensureInitialized()||!m())return!1;const t=await this.adapter.showBanner(e);return this.bannerVisible=t.success,t.success}async hideBanner(){await this._ensureInitialized()&&(await this.adapter.hideBanner(),this.bannerVisible=!1)}isAdAvailable(e){return!this.initialized||!m()?!1:this.adapter.isAdAvailable(e)}async preloadAd(e){return await this._ensureInitialized()?await this.adapter.preloadAd(e):!1}_canShowAd(e){if(this._isCrazyGamesSdkOnlyMode())return!1;if(e==="rewarded")return this.sessionStats.rewardedShown<d.frequencyCaps.maxRewardedPerSession;const t=Date.now(),a=d;return!(t-this.sessionStartTime<a.timing.initialDelay||t-this.lastAdTime<a.timing.globalCooldown||e==="interstitial"&&(t-this.lastInterstitialTime<a.timing.interstitialCooldown||this.sessionStats.interstitialsShown>=a.frequencyCaps.maxInterstitialsPerSession)||e==="rewarded"&&this.sessionStats.rewardedShown>=a.frequencyCaps.maxRewardedPerSession)}canShowInterstitial(){return this._canShowAd("interstitial")}reportLoadingStart(){this._callAdapterMethod("reportLoadingStart")}reportLoadingStop(){this._callAdapterMethod("reportLoadingStop"),this._callAdapterMethod("reportLoadingFinished"),this._callAdapterMethod("reportGameReady")}reportGameplayStart(){this._callAdapterMethod("reportGameplayStart")}reportGameplayStop(){this._callAdapterMethod("reportGameplayStop")}reportHappyTime(){this._callAdapterMethod("reportHappyTime")}resetAttemptStats(){this.attemptStats={continuesUsed:0}}resetSessionStats(){this.sessionStats={interstitialsShown:0,rewardedShown:0,gameOvers:0,levelCompletes:0,continuesUsed:0},this.lastAdTime=0,this.lastInterstitialTime=0,this.sessionStartTime=Date.now()}getAdapterName(){var e;return((e=this.adapter)==null?void 0:e.name)||"None"}getStats(){return{session:{...this.sessionStats},attempt:{...this.attemptStats}}}}const E=new M,C=Object.freeze(Object.defineProperty({__proto__:null,AdManager:E},Symbol.toStringTag,{value:"Module"}));export{C as A,v as B};
